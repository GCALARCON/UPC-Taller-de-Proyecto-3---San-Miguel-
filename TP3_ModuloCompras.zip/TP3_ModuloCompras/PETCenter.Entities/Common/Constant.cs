﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PETCenter.Entities.Common
{
    public class Constant
    {
        public const string nameUser = "user";
        public const string itemsolicitudrecursos = "itemsolicitudrecursos";
        public const string resursoproveedor = "resursoproveedor";
        public const string nameOptions = "options";
        public const string quote = "\"";

        public const int idaplicacion = 1;
        public const int idempresa = 1;
    }
}
