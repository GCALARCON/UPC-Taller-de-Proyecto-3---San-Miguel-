﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PETCenter.Entities.Compras
{
    public class Area
    {
        public int idArea { get; set; }
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
    }
}
