﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PETCenter.Entities.Compras
{
    public class Generador
    {

        public int idProveedor { get; set; }
        public int PuntTerPago { get; set; }
        public int PuntIncidencia { get; set; }
        public string RazonSocial { get; set; }
        public int Puntaje { get; set; }
        public int PuntajeTotal { get; set; }
        public string Periodo { get; set; }


    }
}
