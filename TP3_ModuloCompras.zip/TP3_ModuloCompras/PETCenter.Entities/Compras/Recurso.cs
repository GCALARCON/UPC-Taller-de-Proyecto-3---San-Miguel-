﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PETCenter.Entities.Compras
{
    public class Recurso
    {
        public int idrecurso { get; set; }
        public string codigo { get; set; }
        public string descripcion {get;set;}
    }
}
